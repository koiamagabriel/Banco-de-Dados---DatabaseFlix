# s2/main.py
# -----------------------------------------------------------
# S2 — API de Dados (FastAPI) para o projeto de SVOD
# - Catálogo com restrição por PLANO (comum/premium/delux)
# - Filtros de grafo (gênero/ator/curtidos) + interseção
# - Assinaturas e Pagamentos no Supabase
# - Ajustes: admin por domínio, sem armazenar bandeira de cartão
# - Confirmação de exclusão inline no Admin
# -----------------------------------------------------------

import os, sys, re, bcrypt
from typing import Optional, List, Set, Dict
from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel, Field
from bson import ObjectId
from bson.errors import InvalidId

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from db.supabase_rest import (
    sb_upsert_usuario,
    sb_buscar_usuario_por_email,
    sb_listar_planos,
    sb_salvar_assinatura,
    sb_obter_assinatura,
    sb_salvar_pagamento,
    sb_ping
)
from db.mongo import mongo_db, mongo_ensure_minimal_schema
from db.neo4j_db import neo4j_driver, neo4j_ensure_minimal_schema

app = FastAPI(title="S2 - API de Dados (SVOD)")
NEO4J_DISPONIVEL = False
SUPABASE_OK = False

# -------------------------
# Modelos
# -------------------------
class NovoUsuario(BaseModel):
    nome: str
    email: str
    senha: str
    is_admin: bool = False  # ignorado no servidor; ver regra de domínio

class Login(BaseModel):
    email: str
    senha: str

class NovoTitulo(BaseModel):
    titulo: str
    tipo: str = Field(..., pattern="^(filme|serie)$")
    sinopse: Optional[str] = None
    classificacao: Optional[str] = None
    generos: List[str] = []
    elenco: List[str] = []
    ano: Optional[int] = None
    disponivel: bool = True
    duracao_min: Optional[int] = None        # filme
    temporadas: Optional[int] = None         # série
    eps_por_temp: Optional[List[int]] = None # série
    # visibilidade por plano:
    vis_comum: Optional[bool] = True
    vis_premium: Optional[bool] = True

class GostouPayload(BaseModel):
    user_id: str
    title_id: str

class EscolherPlano(BaseModel):
    user_id: str
    plano_codigo: str  # "comum" | "premium" | "delux"

class PagamentoPayload(BaseModel):
    user_id: str
    plano_codigo: str
    nome_impresso: str
    numero_cartao: str
    validade_mm: int
    validade_aa: int
    pais: str
    endereco1: str
    endereco2: Optional[str] = None
    cidade: str
    estado: str
    cep: str

# -------------------------
# Util — plano do usuário
# -------------------------
def _plano_do_usuario(user_id: Optional[str]) -> str:
    """
    Retorna o código do plano:
      - "comum" (default se user_id ausente ou sem assinatura)
      - "premium"
      - "delux"
    """
    if not user_id:
        return "comum"
    try:
        rows = sb_obter_assinatura(user_id) or []
        if rows:
            pc = (rows[0].get("plano_codigo") or "comum").strip().lower()
            if pc in ("comum", "premium", "delux"):
                return pc
    except Exception:
        pass
    return "comum"

# -------------------------
# Boot / Saúde
# -------------------------
@app.on_event("startup")
def boot():
    global NEO4J_DISPONIVEL, SUPABASE_OK
    mongo_ensure_minimal_schema()

    col = mongo_db().titulos
    # índices úteis
    try:
        col.create_index([("elenco", 1)], name="idx_elenco")
    except Exception:
        pass
    try:
        col.create_index([("vis_comum", 1)], name="idx_vis_comum")
        col.create_index([("vis_premium", 1)], name="idx_vis_premium")
    except Exception:
        pass
    # default de visibilidade em títulos antigos (sem campos)
    try:
        col.update_many({"vis_comum": {"$exists": False}}, {"$set": {"vis_comum": True}})
        col.update_many({"vis_premium": {"$exists": False}}, {"$set": {"vis_premium": True}})
    except Exception:
        pass

    # Neo4j
    try:
        neo4j_ensure_minimal_schema()
        NEO4J_DISPONIVEL = True
        print("[S2] Neo4j disponível.")
    except Exception as e:
        NEO4J_DISPONIVEL = False
        print(f"[S2] Neo4j indisponível (seguindo sem grafo): {e}")

    # Supabase ping
    SUPABASE_OK = bool(sb_ping())
    print(f"[S2] Supabase disponível: {SUPABASE_OK}")

@app.get("/health")
def health():
    return {"ok": True, "neo4j": NEO4J_DISPONIVEL, "supabase": SUPABASE_OK}

# -------------------------
# Usuários / login
# -------------------------
@app.post("/usuarios")
def criar_usuario(dados: NovoUsuario):
    # Regra: e-mail que termina com @admin.com => administrador
    is_admin = dados.email.strip().lower().endswith("@admin.com")
    senha_hash = bcrypt.hashpw(dados.senha.encode(), bcrypt.gensalt()).decode()
    res = sb_upsert_usuario(dados.nome, dados.email, senha_hash, is_admin)
    return {"usuario": res[0] if res else None}

@app.post("/auth/login")
def login(payload: Login):
    u = sb_buscar_usuario_por_email(payload.email)
    if not u:
        raise HTTPException(status_code=401, detail="Credenciais inválidas")
    u = u[0]
    if not bcrypt.checkpw(payload.senha.encode(), u["senha_hash"].encode()):
        raise HTTPException(status_code=401, detail="Credenciais inválidas")
    # retorna usuário "limpo"
    return {"usuario": {"id": u["id"], "nome": u["nome"], "email": u["email"], "is_admin": u["is_admin"]}}

# -------------------------
# Planos / Assinaturas / Pagamentos
# -------------------------
@app.get("/planos")
def listar_planos():
    planos = sb_listar_planos() or []
    planos.sort(key=lambda x: x.get("codigo",""))
    return {"planos": planos}

@app.get("/assinaturas/me")
def assinatura_me(user_id: str):
    rows = sb_obter_assinatura(user_id) or []
    if not rows:
        return {"assinatura": None}
    return {"assinatura": rows[0]}

@app.post("/assinaturas")
def criar_ou_atualizar_assinatura(p: EscolherPlano):
    if p.plano_codigo not in ("comum", "premium", "delux"):
        raise HTTPException(status_code=400, detail="plano inválido")
    rows = sb_salvar_assinatura(p.user_id, p.plano_codigo)
    return {"assinatura": rows[0] if rows else None}

@app.post("/pagamentos")
def gravar_pagamento(p: PagamentoPayload):
    # Armazenamos apenas dados não sensíveis (sem bandeira; apenas last4)
    numsomente = re.sub(r"\D", "", p.numero_cartao or "")
    last4 = numsomente[-4:] if len(numsomente) >= 4 else numsomente
    rows = sb_salvar_pagamento(
        user_id=p.user_id,
        plano_codigo=p.plano_codigo,
        nome_impresso=p.nome_impresso,
        last4=last4,
        validade_mm=int(p.validade_mm),
        validade_aa=int(p.validade_aa),
        pais=p.pais,
        endereco1=p.endereco1,
        endereco2=p.endereco2,
        cidade=p.cidade,
        estado=p.estado,
        cep=p.cep,
    )
    return {"pagamento": rows[0] if rows else None}

# -------------------------
# Helpers — filtros via Neo4j
# -------------------------
def _ids_por_generos(generos: List[str]) -> Set[str]:
    if not NEO4J_DISPONIVEL or not generos:
        return set()
    generos_lower = [g.lower() for g in generos]
    with neo4j_driver().session() as s:
        cur = s.run("""
            MATCH (t:Title)-[:PERTENCE_A]->(g:Genre)
            WHERE toLower(g.nome) IN $generos
            RETURN DISTINCT t.id AS id
        """, generos=generos_lower)
        return {str(rec["id"]).strip() for rec in cur}

def _ids_por_ator(ator: str) -> Set[str]:
    if not NEO4J_DISPONIVEL or not (ator and ator.strip()):
        return set()
    ator_lower = ator.strip().lower()
    with neo4j_driver().session() as s:
        cur = s.run("""
            MATCH (a:Actor)
            WHERE toLower(a.nome) = $ator
            MATCH (a)-[:ATUOU_EM]->(t:Title)
            RETURN DISTINCT t.id AS id
        """, ator=ator_lower)
        return {str(rec["id"]).strip() for rec in cur}

def _ids_curtidos(user_id: str) -> Set[str]:
    if not NEO4J_DISPONIVEL or not (user_id and user_id.strip()):
        return set()
    uid = user_id.strip()
    with neo4j_driver().session() as s:
        cur = s.run("""
            MATCH (u:User {id: $uid})-[:GOSTOU]->(t:Title)
            RETURN DISTINCT t.id AS id
        """, uid=uid)
        return {str(rec["id"]).strip() for rec in cur}

def _ids_por_grafo(generos: Optional[List[str]], ator: Optional[str], user_id: Optional[str], curtidos: bool) -> Optional[Set[str]]:
    filtros_sets: List[Set[str]] = []
    if generos:
        filtros_sets.append(_ids_por_generos(generos))
    if ator:
        filtros_sets.append(_ids_por_ator(ator))
    if curtidos and user_id:
        filtros_sets.append(_ids_curtidos(user_id))
    if not filtros_sets:
        return None
    ids = filtros_sets[0]
    for sset in filtros_sets[1:]:
        ids &= sset
    return ids

def _buscar_por_ids_mongo(ids: Set[str], q: Optional[str], limite: int, pular: int, plano_codigo: str):
    col = mongo_db().titulos

    oids, sids = [], []
    for sid in ids:
        try:
            oids.append(ObjectId(sid))
        except Exception:
            sids.append(sid)

    pipeline = []
    if q:
        pipeline.append({"$match": {"$text": {"$search": q}}})

    vis_match: Dict[str, bool] | None = None
    if plano_codigo == "comum":
        vis_match = {"vis_comum": True}
    elif plano_codigo == "premium":
        vis_match = {"vis_premium": True}
    # delux sem filtro adicional

    base_match = {
        "$or": [
            {"disponivel": True},
            {"disponivel": {"$exists": False}}
        ]
    }
    if vis_match:
        base_match.update(vis_match)
    pipeline.append({"$match": base_match})

    if oids and sids:
        pipeline.append({"$addFields": {"idstr": {"$toString": "$_id"}}})
        pipeline.append({"$match": {"$or": [{"_id": {"$in": oids}}, {"idstr": {"$in": sids}}]}})
    elif oids:
        pipeline.append({"$match": {"_id": {"$in": oids}}})
    elif sids:
        pipeline.append({"$addFields": {"idstr": {"$toString": "$_id"}}})
        pipeline.append({"$match": {"idstr": {"$in": sids}}})
    else:
        return []

    if pular:
        pipeline.append({"$skip": int(pular)})
    if limite:
        pipeline.append({"$limit": int(limite)})

    itens = list(col.aggregate(pipeline))
    for it in itens:
        it["id"] = it.get("idstr") or str(it["_id"])
        it.pop("idstr", None)
        it.pop("_id", None)
    return itens

# -------------------------
# Catálogo (Neo4j → Mongo) com restrição por PLANO
# -------------------------
@app.get("/catalogo/generos")
def catalogo_generos():
    gens = list(mongo_db().titulos.distinct("generos"))
    gens = [g for g in gens if isinstance(g, str) and g.strip()]
    gens.sort(key=lambda x: x.lower())
    return gens

def _montar_filtro_catalogo(q: Optional[str], generos_csv: Optional[str], ator: Optional[str], plano_codigo: str):
    filtro = {"disponivel": True}
    if q:
        filtro["$text"] = {"$search": q}
    if generos_csv:
        lista = [g.strip() for g in generos_csv.split(",") if g.strip()]
        if lista:
            filtro["generos"] = {"$in": lista}
    if ator:
        pattern = f"^{re.escape(ator)}$"
        filtro["elenco"] = {"$regex": pattern, "$options": "i"}

    if plano_codigo == "comum":
        filtro["vis_comum"] = True
    elif plano_codigo == "premium":
        filtro["vis_premium"] = True

    return filtro

@app.get("/catalogo")
def listar_catalogo(
    q: Optional[str] = None,
    generos: Optional[str] = Query(default=None),
    ator: Optional[str] = None,
    user_id: Optional[str] = None,
    curtidos: bool = Query(default=False),
    limite: int = 50,
    pular: int = 0
):
    plano_codigo = _plano_do_usuario(user_id)

    # premium não pode usar curtidos; comum não tem filtros
    if plano_codigo == "premium":
        curtidos = False
    if plano_codigo == "comum":
        q = None
        generos = None
        ator = None
        curtidos = False

    lista_generos = [g.strip() for g in generos.split(",")] if generos else []

    ids = _ids_por_grafo(
        generos=lista_generos if lista_generos else None,
        ator=ator,
        user_id=user_id if curtidos else None,
        curtidos=curtidos
    )

    if ids is not None:
        if not ids:
            return {"itens": []}
        itens = _buscar_por_ids_mongo(ids, q, limite, pular, plano_codigo)
        return {"itens": itens}

    # Sem filtros de grafo ativos → só Mongo (com restrição por plano)
    col = mongo_db().titulos
    filtro = _montar_filtro_catalogo(q, generos, ator, plano_codigo)
    itens = list(col.find(filtro).skip(pular).limit(limite))
    for it in itens:
        it["id"] = str(it["_id"]); del it["_id"]
    return {"itens": itens}

@app.get("/catalogo/{id_titulo}")
def detalhe_titulo(id_titulo: str, user_id: Optional[str] = None):
    plano_codigo = _plano_do_usuario(user_id)

    col = mongo_db().titulos
    try:
        oid = ObjectId(id_titulo)
    except (InvalidId, TypeError):
        raise HTTPException(status_code=400, detail="ID de título inválido")

    doc = col.find_one({"_id": oid})
    if not doc:
        raise HTTPException(status_code=404, detail="Título não encontrado")

    # bloqueio por plano no detalhe também:
    if plano_codigo == "comum" and not (doc.get("vis_comum", True)):
        raise HTTPException(status_code=403, detail="Título indisponível para seu plano")
    if plano_codigo == "premium" and not (doc.get("vis_premium", True)):
        raise HTTPException(status_code=403, detail="Título indisponível para seu plano")

    doc["id"] = str(doc["_id"]); del doc["_id"]
    return {"titulo": doc}

# -------------------------
# Admin
# -------------------------
@app.get("/admin/titulos/lista")
def admin_listar_titulos():
    col = mongo_db().titulos
    itens = list(col.find({}, {"_id": 1, "titulo": 1, "tipo": 1}).sort("titulo", 1))
    return [{"id": str(it["_id"]), "titulo": it.get("titulo"), "tipo": it.get("tipo")} for it in itens]

@app.post("/admin/titulos")
def cadastrar_titulo(novo: NovoTitulo):
    if novo.tipo == "filme":
        if not novo.duracao_min or novo.duracao_min <= 0:
            raise HTTPException(status_code=400, detail="Para filmes, informe 'duracao_min' (> 0).")
    else:
        if not novo.temporadas or novo.temporadas <= 0:
            raise HTTPException(status_code=400, detail="Para séries, informe 'temporadas' (> 0).")
        if not novo.eps_por_temp or len(novo.eps_por_temp) != novo.temporadas:
            raise HTTPException(status_code=400, detail="Para séries, 'eps_por_temp' deve cobrir todas as temporadas.")
        if any((v is None or v <= 0) for v in novo.eps_por_temp):
            raise HTTPException(status_code=400, detail="Todos os valores de 'eps_por_temp' devem ser > 0.")

    vis_comum = True if novo.vis_comum is None else bool(novo.vis_comum)
    vis_premium = True if novo.vis_premium is None else bool(novo.vis_premium)

    col = mongo_db().titulos
    doc = {k: v for k, v in novo.dict().items() if v is not None}
    doc["vis_comum"] = vis_comum
    doc["vis_premium"] = vis_premium

    ins = col.insert_one(doc)
    id_str = str(ins.inserted_id)

    if NEO4J_DISPONIVEL:
        try:
            with neo4j_driver().session() as s:
                s.run("""
                    MERGE (t:Title {id: $id})
                    SET t.titulo = $titulo, t.tipo = $tipo
                """, id=id_str, titulo=novo.titulo, tipo=novo.tipo)
                for g in novo.generos or []:
                    s.run("""
                        MERGE (g:Genre {nome: $g})
                        WITH g
                        MATCH (t:Title {id: $id})
                        MERGE (t)-[:PERTENCE_A]->(g)
                    """, id=id_str, g=g)
                for a in novo.elenco or []:
                    s.run("""
                        MERGE (a:Actor {nome: $a})
                        WITH a
                        MATCH (t:Title {id: $id})
                        MERGE (a)-[:ATUOU_EM]->(t)
                    """, id=id_str, a=a)
        except Exception as e:
            return {"id": id_str, "grafo": {"ok": False, "erro": str(e)}}

    return {"id": id_str, "grafo": {"ok": NEO4J_DISPONIVEL}}

@app.delete("/admin/titulos/{id_titulo}")
def excluir_titulo(id_titulo: str):
    col = mongo_db().titulos
    try:
        oid = ObjectId(id_titulo)
    except (InvalidId, TypeError):
        raise HTTPException(status_code=400, detail="ID de título inválido")

    res = col.delete_one({"_id": oid})

    if NEO4J_DISPONIVEL:
        try:
            with neo4j_driver().session() as s:
                s.run("MATCH (t:Title {id:$id}) DETACH DELETE t", id=id_titulo)
        except Exception as e:
            return {"removidos": res.deleted_count, "grafo": {"ok": False, "erro": str(e)}}

    return {"removidos": res.deleted_count, "grafo": {"ok": NEO4J_DISPONIVEL}}

# -------------------------
# Grafo (curtidos)
# -------------------------
@app.post("/grafo/gostou")
def marcar_gostou(p: GostouPayload):
    if not NEO4J_DISPONIVEL:
        return {"ok": False, "erro": "grafo (Neo4j) indisponível no momento"}
    uid = str(p.user_id).strip()
    tid = str(p.title_id).strip()
    try:
        with neo4j_driver().session() as s:
            s.run("""
                MERGE (u:User {id: $uid})
                MERGE (t:Title {id: $tid})
                MERGE (u)-[:GOSTOU {ts: datetime()}]->(t)
            """, uid=uid, tid=tid)
        return {"ok": True}
    except Exception as e:
        return {"ok": False, "erro": str(e)}

@app.delete("/grafo/gostou")
def desmarcar_gostou(user_id: str, title_id: str):
    if not NEO4J_DISPONIVEL:
        return {"ok": False, "erro": "grafo (Neo4j) indisponível no momento"}
    uid = str(user_id).strip()
    tid = str(title_id).strip()
    try:
        with neo4j_driver().session() as s:
            rec = s.run("""
                MATCH (u:User {id:$uid})-[r:GOSTOU]->(t:Title {id:$tid})
                DELETE r
                RETURN 1 AS ok
            """, uid=uid, tid=tid).single()
        return {"ok": True if rec else False}
    except Exception as e:
        return {"ok": False, "erro": str(e)}

@app.get("/grafo/curtidos")
def listar_ids_curtidos(
    user_id: str,
    title_ids: Optional[str] = Query(default=None, description="CSV opcional para subset check")
):
    if not NEO4J_DISPONIVEL:
        return {"ok": False, "neo4j": False, "title_ids": [], "count": 0}
    uid = str(user_id).strip()
    try:
        with neo4j_driver().session() as s:
            if title_ids:
                ids = [x.strip() for x in title_ids.split(",") if x.strip()]
                cursor = s.run("""
                    UNWIND $ids AS tid
                    MATCH (u:User {id: $uid})-[:GOSTOU]->(t:Title {id: tid})
                    RETURN t.id AS id
                """, uid=uid, ids=ids)
            else:
                cursor = s.run("""
                    MATCH (u:User {id: $uid})-[:GOSTOU]->(t:Title)
                    RETURN t.id AS id
                """, uid=uid)
            recs = [str(rec["id"]).strip() for rec in cursor]
        return {"ok": True, "neo4j": True, "title_ids": recs, "count": len(recs)}
    except Exception as e:
        return {"ok": False, "neo4j": True, "erro": str(e), "title_ids": [], "count": 0}
