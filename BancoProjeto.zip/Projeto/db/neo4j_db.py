# Projeto/db/neo4j_db.py
from neo4j import GraphDatabase

# (use os seus mesmos dados)
NEO4J_URI = "neo4j+ssc://b9a70cb1.databases.neo4j.io"
NEO4J_USER = "neo4j"
NEO4J_PASSWORD = "e4Ul5kRlY1KdK7MWwMdhyl7UQlmZlmuhh7SOlJyQm50"

_driver = GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USER, NEO4J_PASSWORD))

def neo4j_driver():
    return _driver

def neo4j_verify():
    _driver.verify_connectivity()
    return True

def neo4j_ping():
    with _driver.session() as s:
        r = s.run("RETURN 1 AS ok").single()
        return bool(r and r["ok"] == 1)

def neo4j_ensure_minimal_schema():
    with _driver.session() as s:
        # Constraints (idempotentes)
        s.run("CREATE CONSTRAINT user_id IF NOT EXISTS FOR (u:User) REQUIRE u.id IS UNIQUE;")
        s.run("CREATE CONSTRAINT title_id IF NOT EXISTS FOR (t:Title) REQUIRE t.id IS UNIQUE;")
        s.run("CREATE CONSTRAINT genre_nome IF NOT EXISTS FOR (g:Genre) REQUIRE g.nome IS UNIQUE;")
        s.run("CREATE CONSTRAINT actor_nome IF NOT EXISTS FOR (a:Actor) REQUIRE a.nome IS UNIQUE;")

        # SEED idempotente — MERGE APENAS COM A CHAVE ÚNICA
        s.run("""
            MERGE (u:User {id: 'u-demo'})
            SET u.nome = 'Usuário Demo'
        """)

        s.run("""
            MERGE (t:Title {id: 'T-001'})
            SET t.titulo = 'Exemplo: O Drama de 2019',
                t.tipo   = 'filme'
        """)

        s.run("""
            MERGE (g:Genre {nome: 'Drama'})
        """)

        s.run("""
            MERGE (a:Actor {nome: 'Ator A'})
        """)

        s.run("""
            MATCH (t:Title {id: 'T-001'}), (g:Genre {nome:'Drama'})
            MERGE (t)-[:PERTENCE_A]->(g)
        """)

        s.run("""
            MATCH (a:Actor {nome:'Ator A'}), (t:Title {id:'T-001'})
            MERGE (a)-[:ATUOU_EM]->(t)
        """)

        # Relação obrigatória do projeto: apenas GOSTOU
        s.run("""
            MATCH (u:User {id: 'u-demo'}), (t:Title {id:'T-001'})
            MERGE (u)-[:GOSTOU {ts: datetime()}]->(t)
        """)
