# db/supabase_rest.py
# ------------------------------------------------------------
# Acesso ao Supabase via REST (PostgREST)
# - Leitura com ANON KEY
# - Escrita com SERVICE KEY se fornecida (recomendado) ou ANON (exige RLS permissiva)
# ------------------------------------------------------------
import os
import json
import urllib.request
import urllib.parse
import urllib.error

# >>> SUAS CONFIGURAÇÕES <<<
SUPABASE_URL = "https://blueljkncrvcwjlaqieu.supabase.co"
SUPABASE_KEY = "sb_publishable_02wiMg70mYxA3nWpbH2Aog_DWD9aHpr"   # ANON/PUBLIC key
# Agora também lê do ambiente: export SUPABASE_SERVICE_KEY=...
SUPABASE_SERVICE_KEY = os.getenv("SUPABASE_SERVICE_KEY", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJsdWVsamtuY3J2Y3dqbGFxaWV1Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc2MTE2NTYzMywiZXhwIjoyMDc2NzQxNjMzfQ.G_ph1LpxzixsrL49nNJ830lueOMjTceKvVpLmO1r0J4")

# ------------------------------------------------------------
def _headers_read():
    return {
        "apikey": SUPABASE_KEY,
        "Authorization": f"Bearer {SUPABASE_KEY}",
        "Content-Type": "application/json",
        "Prefer": "return=representation",
    }

def _headers_write(upsert: bool = False):
    key = SUPABASE_SERVICE_KEY or SUPABASE_KEY
    h = {
        "apikey": key,
        "Authorization": f"Bearer {key}",
        "Content-Type": "application/json",
        "Prefer": "return=representation",
    }
    if upsert:
        h["Prefer"] = "resolution=merge-duplicates,return=representation"
    return h

# compat com versões antigas (se algum ponto do S2 usar constantes)
HEADERS_UPSERT = _headers_write(upsert=True)
HEADERS_WRITE  = _headers_write(upsert=False)

def _http(metodo: str, caminho: str, params: dict | None = None, corpo: dict | list | None = None, headers: dict | None = None):
    url = f"{SUPABASE_URL}{caminho}"
    if params:
        url += "?" + urllib.parse.urlencode(params, doseq=True)
    data = None
    if corpo is not None:
        data = json.dumps(corpo).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers=(headers or _headers_read()), method=metodo)
    with urllib.request.urlopen(req, timeout=30) as resp:
        txt = resp.read().decode("utf-8")
        return json.loads(txt) if txt else None

def _http_with_status(metodo: str, caminho: str, params: dict | None = None, corpo: dict | list | None = None, headers: dict | None = None):
    """
    Variante que não levanta exceção em 4xx/5xx; devolve (status_code:int, data:any|None, raw_text:str|None).
    Útil para registrar logs sem quebrar o app e para tentar fallbacks.
    """
    url = f"{SUPABASE_URL}{caminho}"
    if params:
        url += "?" + urllib.parse.urlencode(params, doseq=True)
    data = None
    if corpo is not None:
        data = json.dumps(corpo).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers=(headers or _headers_read()), method=metodo)
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            txt = resp.read().decode("utf-8")
            return resp.getcode(), (json.loads(txt) if txt else None), txt
    except urllib.error.HTTPError as e:
        try:
            err_txt = e.read().decode("utf-8")
        except Exception:
            err_txt = None
        parsed = None
        try:
            parsed = json.loads(err_txt) if err_txt else None
        except Exception:
            parsed = None
        return e.code, parsed, err_txt

# ------------------------------------------------------------
# PING
def sb_ping() -> bool:
    try:
        _http("GET", "/rest/v1/usuarios", params={"select": "id", "limit": "1"})
        return True
    except Exception as e:
        print("Supabase REST ping falhou:", e)
        return False

# ------------------------------------------------------------
# USUÁRIOS
def sb_upsert_usuario(nome: str, email: str, senha_hash: str, is_admin: bool):
    body = [{
        "nome": nome,
        "email": email,
        "senha_hash": senha_hash,
        "is_admin": is_admin,
    }]
    return _http(
        "POST",
        "/rest/v1/usuarios",
        params={"on_conflict": "email"},
        corpo=body,
        headers=_headers_write(upsert=True),
    )

def sb_select_usuario_por_email(email: str):
    return _http(
        "GET",
        "/rest/v1/usuarios",
        params={"select": "id,nome,email,senha_hash,is_admin", "email": f"eq.{email}", "limit": "1"},
        headers=_headers_read(),
    )

# compat com versões antigas do seu S2
def sb_buscar_usuario_por_email(email: str):
    return sb_select_usuario_por_email(email)

# ------------------------------------------------------------
# LOGS S1
def _sanitize_log_row(endpoint, metodo, req_payload, res_payload, status_code, latency_ms, erro, user_id):
    # garante tipos simples/serializáveis e defaults
    def _to_jsonable(x):
        try:
            json.dumps(x)
            return x
        except Exception:
            return str(x)
    return [{
        "endpoint": str(endpoint) if endpoint is not None else "",
        "metodo": str(metodo) if metodo is not None else "",
        "req_payload": _to_jsonable(req_payload),
        "res_payload": _to_jsonable(res_payload),
        "status_code": int(status_code) if isinstance(status_code, int) else 0,
        "latency_ms": int(latency_ms) if isinstance(latency_ms, int) else 0,
        "erro": str(erro) if erro is not None else None,
        "user_id": str(user_id) if user_id is not None else None,
    }]

def sb_registrar_log_s1(endpoint: str, metodo: str, req_payload: dict | None, res_payload: dict | None,
                        status_code: int | None, latency_ms: int, erro: str | None, user_id: str | None):
    body = _sanitize_log_row(endpoint, metodo, req_payload, res_payload, status_code, latency_ms, erro, user_id)

    # 1) tenta na tabela 'log_s1' (singular)
    status, data, _ = _http_with_status(
        "POST",
        "/rest/v1/log_s1",
        params={},
        corpo=body,
        headers=_headers_write(upsert=False),
    )
    if status in (200, 201):
        return data

    # 2) fallback: tenta 'logs_s1' (plural), caso a tabela tenha outro nome
    if status == 404:
        status2, data2, _ = _http_with_status(
            "POST",
            "/rest/v1/logs_s1",
            params={},
            corpo=body,
            headers=_headers_write(upsert=False),
        )
        if status2 in (200, 201):
            return data2
        else:
            # imprime no console para facilitar diagnóstico, mas não explode o app
            print(f"[sb_registrar_log_s1] Falha no fallback 'logs_s1' (status {status2}). Verifique RLS/nomes/colunas.")
            return None
    else:
        # 401/403 costumam ser RLS sem permissão quando SUPABASE_SERVICE_KEY não está definido
        if status in (401, 403):
            print("[sb_registrar_log_s1] Permissão negada (RLS). Defina SUPABASE_SERVICE_KEY ou abra a RLS para inserts.")
        else:
            print(f"[sb_registrar_log_s1] Falha ao inserir no 'log_s1' (status {status}).")
        return None

# compat com seu S1
def sb_inserir_log_s1(endpoint, metodo, req_payload, res_payload, status_code, latency_ms, user_id, erro):
    return sb_registrar_log_s1(endpoint, metodo, req_payload, res_payload, status_code, latency_ms, erro, user_id)

# ------------------------------------------------------------
# PLANOS / ASSINATURAS / PAGAMENTOS
def sb_listar_planos():
    return _http(
        "GET",
        "/rest/v1/planos",
        params={"select": "codigo,nome,descricao", "order": "codigo.asc"},
        headers=_headers_read(),
    )

def sb_salvar_assinatura(user_id: str, plano_codigo: str):
    body = [{
        "user_id": user_id,
        "plano_codigo": plano_codigo,
        "status": "ativo",
    }]
    return _http(
        "POST",
        "/rest/v1/assinaturas",
        params={"on_conflict": "user_id"},
        corpo=body,
        headers=_headers_write(upsert=True),
    )

def sb_obter_assinatura(user_id: str):
    return _http(
        "GET",
        "/rest/v1/assinaturas",
        params={"select": "user_id,plano_codigo,status,created_at", "user_id": f"eq.{user_id}", "limit": "1"},
        headers=_headers_read(),
    )

def sb_salvar_pagamento(**dados):
    """
    Insere pagamento em 'pagamentos'.
    Campos esperados (schema atual, sem 'brand'):
      - user_id, plano_codigo, nome_impresso, last4, validade_mm, validade_aa,
        pais, endereco1, endereco2 (opcional), cidade, estado, cep
    """
    body = [dados]
    return _http(
        "POST",
        "/rest/v1/pagamentos",
        params={},
        corpo=body,
        headers=_headers_write(upsert=False),
    )
