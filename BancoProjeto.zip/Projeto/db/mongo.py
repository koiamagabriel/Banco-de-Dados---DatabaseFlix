# Projeto/db/mongo.py
from pymongo import MongoClient, ASCENDING, TEXT
from pymongo.server_api import ServerApi
import certifi

MONGODB_URI = "mongodb+srv://koiamagabriel_db_user:Koiama9164@projetobanco.hjimmbv.mongodb.net/?retryWrites=true&w=majority&appName=ProjetoBanco"
MONGODB_DBNAME = "svod"

_client = MongoClient(
    MONGODB_URI,
    tls=True,
    tlsCAFile=certifi.where(),
    server_api=ServerApi('1'),
)
_db = _client[MONGODB_DBNAME]

def mongo_db():
    return _db

def mongo_ping():
    _client.admin.command("ping")
    return True

def mongo_ensure_minimal_schema():
    titulos = _db["titulos"]
    titulos.create_index([("titulo", TEXT), ("sinopse", TEXT)], name="text_titulo_sinopse")
    titulos.create_index([("generos", ASCENDING)], name="idx_generos")
    if titulos.estimated_document_count() == 0:
        titulos.insert_one({
            "titulo": "Exemplo: O Drama de 2019",
            "tipo": "filme",
            "sinopse": "Um drama ambientado em 2019.",
            "elenco": ["Ator A", "Atriz B"],
            "generos": ["Drama"],
            "classificacao": "16",
            "duracao_min": 120,
            "ano": 2019,
            "disponivel": True
        })
