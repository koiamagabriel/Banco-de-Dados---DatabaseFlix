# s1/app.py
# -----------------------------------------------------------
# S1 — Interface (Streamlit)
# - Fluxo de planos e pagamento (Supabase)
# - Catálogo com restrição por PLANO
# - Filtros (gêneros/ator) e curtidos (apenas DELUX)
# - Ajustes: clique em ator não faz nada no plano COMUM; confirmação inline na exclusão
# Execução: py -m streamlit run s1/app.py
# -----------------------------------------------------------

import os, sys, time, re, requests, streamlit as st

# garantir import de "db" quando rodar de /s1
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from db.supabase_rest import sb_inserir_log_s1

S2_URL = "http://127.0.0.1:8000"

# -----------------------------
# Chamada HTTP com log em RDB
# -----------------------------
def chamar_api(metodo: str, caminho: str, payload=None, user_id: str | None = None):
    url = f"{S2_URL}{caminho}"
    ini = time.time()
    status, resposta, erro_txt = None, None, None
    try:
        if metodo == "GET":
            r = requests.get(url, params=payload, timeout=20)
        elif metodo == "POST":
            r = requests.post(url, json=payload, timeout=20)
        elif metodo == "DELETE":
            r = requests.delete(url, params=payload, timeout=20)
        else:
            raise ValueError("método inválido")
        status = r.status_code
        resposta = r.json() if r.content else None
        return resposta
    except Exception as e:
        erro_txt = str(e)
        st.error(f"Erro ao chamar {caminho}: {erro_txt}")
        return None
    finally:
        lat = int((time.time() - ini) * 1000)
        try:
            sb_inserir_log_s1(
                endpoint=caminho,
                metodo=metodo,
                req_payload=payload,
                res_payload=resposta,
                status_code=status,
                latency_ms=lat,
                user_id=user_id,
                erro=erro_txt
            )
        except Exception:
            pass

# -----------------------------
# Estado de sessão
# -----------------------------
def _init_state():
    ss = st.session_state
    ss.setdefault("usuario", None)
    ss.setdefault("tela", "login")
    ss.setdefault("tela_param", None)

    # filtros catálogo
    ss.setdefault("filtro_generos", [])
    ss.setdefault("tmp_generos_sel", [])
    ss.setdefault("filtro_ator", None)
    ss.setdefault("filtro_curtidos", False)

    # admin (excluir inline)
    ss.setdefault("admin_sel_nome", "— selecione —")
    ss.setdefault("admin_sel_id", None)
    ss.setdefault("admin_sel_titulo", None)
    # >>> FLAG para reset seguro do select após excluir/cancelar
    ss.setdefault("admin_reset_select", False)

    # planos/pagamento
    ss.setdefault("plano_codigo", None)   # "comum" | "premium" | "delux"
    ss.setdefault("plano_sel", None)      # seleção intermediária
    ss.setdefault("tem_assinatura", False)

_init_state()

# -----------------------------
# Estilo (coração primário)
# -----------------------------
st.markdown("""
<style>
div.stButton > button[kind="primary"] {
    background-color: #d32f2f !important;
    color: #ffffff !important;
    border: 1px solid #b71c1c !important;
}
</style>
""", unsafe_allow_html=True)

def _forcar_rerun():
    try:
        st.rerun()
    except Exception:
        try:
            st.experimental_rerun()
        except Exception:
            pass

def ir_para(tela: str, param=None, rerun: bool = True):
    st.session_state.tela = tela
    st.session_state.tela_param = param
    if rerun:
        _forcar_rerun()

# -----------------------------
# Plano helpers
# -----------------------------
def _carregar_plano_atual():
    u = st.session_state.usuario
    if not u:
        return
    r = chamar_api("GET", "/assinaturas/me", {"user_id": u["id"]}, user_id=u["id"])
    if r and r.get("assinatura"):
        st.session_state.plano_codigo = r["assinatura"]["plano_codigo"]
        st.session_state.tem_assinatura = True
    else:
        st.session_state.plano_codigo = None
        st.session_state.tem_assinatura = False

def _capacidade_plano():
    pc = st.session_state.plano_codigo or "comum"
    return {
        "is_comum": pc == "comum",
        "is_premium": pc == "premium",
        "is_delux": pc == "delux",
        # regras de UI:
        "pode_curtir": pc == "delux",             # só delux
        "pode_filtrar_generos": pc in ("premium","delux"),
        "pode_buscar_texto": pc in ("premium","delux"),  # comum não filtra
        "pode_filtrar_ator": pc == "delux",       # apenas delux
    }

# -----------------------------
# Telas
# -----------------------------
def cabecalho():
    col1, col2 = st.columns([4, 2])
    with col1:
        titulo = "DataBaseFlix"
        pc = st.session_state.plano_codigo
        if pc:
            titulo += f" — Plano: {pc.upper()}"
        st.title(titulo)
    with col2:
        if st.session_state.usuario:
            if st.button("Sair"):
                # reset total
                for k in list(st.session_state.keys()):
                    if k not in ("_session_state","_is_running_with_streamlit"):
                        st.session_state.pop(k, None)
                _init_state()
                ir_para("login")

def tela_login():
    st.subheader("Login")
    email = st.text_input("E-mail")
    senha = st.text_input("Senha", type="password")

    c1, c2 = st.columns(2)
    with c1:
        if st.button("Entrar"):
            res = chamar_api("POST", "/auth/login", {"email": email, "senha": senha})
            if res and "usuario" in res:
                st.session_state.usuario = res["usuario"]
                _carregar_plano_atual()
                # se não tiver plano, vai para escolha
                if not st.session_state.tem_assinatura:
                    st.toast("Escolha um plano para continuar.", icon="ℹ️")
                    ir_para("planos")
                else:
                    st.toast(f"Bem-vindo(a), {res['usuario']['nome']}!", icon="✅")
                    ir_para("catalogo")
    with c2:
        if st.button("Cadastre-se"):
            ir_para("cadastro")

def tela_cadastro():
    st.subheader("Cadastro de Usuário")
    nome = st.text_input("Nome")
    email = st.text_input("E-mail")
    senha = st.text_input("Senha", type="password")

    c1, c2 = st.columns(2)
    with c1:
        if st.button("Criar conta"):
            if not (nome and email and senha):
                st.warning("Preencha nome, e-mail e senha.")
            else:
                res = chamar_api("POST", "/usuarios", {"nome": nome, "email": email, "senha": senha})
                if res and res.get("usuario"):
                    # já entra no fluxo de plano
                    st.session_state.usuario = res["usuario"]
                    st.session_state.plano_codigo = None
                    st.session_state.tem_assinatura = False
                    st.toast("Usuário criado. Escolha um plano para continuar.", icon="✅")
                    ir_para("planos")
    with c2:
        if st.button("Já tenho conta"):
            ir_para("login")

def tela_planos():
    st.subheader("Escolha seu plano")
    u = st.session_state.usuario
    if not u:
        st.info("Faça login para continuar.")
        if st.button("Ir para login"):
            ir_para("login")
        return

    r = chamar_api("GET", "/planos")
    planos = (r or {}).get("planos", [])
    # fallback se tabela não estiver populada
    if not planos:
        planos = [
            {"codigo": "comum",  "nome": "Mensal Comum",  "descricao": "Catálogo limitado, sem filtros."},
            {"codigo": "premium","nome": "Mensal Premium","descricao": "Catálogo selecionado + filtro por gêneros."},
            {"codigo": "delux",  "nome": "Mensal Delux",  "descricao": "Catálogo completo + curtidos + todos filtros."},
        ]

    cols = st.columns(3)
    for i, p in enumerate(planos[:3]):
        with cols[i]:
            st.markdown(f"**{p['nome']}**")
            st.caption(p.get("descricao",""))
            if st.button("Selecionar", key=f"pl_{p['codigo']}"):
                st.session_state.plano_sel = p["codigo"]
                ir_para("pagamento")

    if st.button("Voltar"):
        ir_para("login")

def _valida_mm_aa(mm: str, aa: str):
    try:
        m = int(mm); a = int(aa)
        return 1 <= m <= 12 and 0 <= a <= 99
    except Exception:
        return False

def tela_pagamento():
    st.subheader("Pagamento")
    u = st.session_state.usuario
    if not u or not st.session_state.plano_sel:
        st.warning("Selecione um plano antes de continuar.")
        if st.button("Voltar aos planos"):
            ir_para("planos")
        return

    st.write(f"Plano escolhido: **{st.session_state.plano_sel.upper()}**")

    c1, c2 = st.columns(2)
    with c1:
        nome_impresso = st.text_input("Nome impresso no cartão")
        numero_cartao = st.text_input("Número do cartão")
        colmm, colaa = st.columns(2)
        with colmm:
            validade_mm = st.text_input("MM", value="12")
        with colaa:
            validade_aa = st.text_input("AA", value="29")
    with c2:
        pais = st.text_input("País", value="BR")
        endereco1 = st.text_input("Endereço (linha 1)")
        endereco2 = st.text_input("Endereço (linha 2)", value="")
        cidade = st.text_input("Cidade")
        estado = st.text_input("Estado/UF")
        cep = st.text_input("CEP")

    if st.button("Confirmar e ativar assinatura", type="primary"):
        if not (nome_impresso and numero_cartao and _valida_mm_aa(validade_mm, validade_aa) and pais and endereco1 and cidade and estado and cep):
            st.warning("Preencha todos os campos obrigatórios corretamente.")
        else:
            # 1) grava pagamento (brand não coletado no S2)
            pagar = chamar_api("POST", "/pagamentos", {
                "user_id": u["id"],
                "plano_codigo": st.session_state.plano_sel,
                "nome_impresso": nome_impresso,
                "numero_cartao": numero_cartao,
                "validade_mm": int(validade_mm),
                "validade_aa": int(validade_aa),
                "pais": pais,
                "endereco1": endereco1,
                "endereco2": endereco2 or None,
                "cidade": cidade,
                "estado": estado,
                "cep": cep
            }, user_id=u["id"])

            # 2) cria/atualiza assinatura
            ass = chamar_api("POST", "/assinaturas", {
                "user_id": u["id"],
                "plano_codigo": st.session_state.plano_sel
            }, user_id=u["id"])

            if (pagar and pagar.get("pagamento")) and (ass and ass.get("assinatura")):
                st.session_state.plano_codigo = st.session_state.plano_sel
                st.session_state.tem_assinatura = True
                st.toast("Assinatura ativada com sucesso!", icon="✅")
                ir_para("catalogo")
            else:
                st.error("Não foi possível ativar a assinatura agora.")

    if st.button("Voltar aos planos"):
        ir_para("planos")

def _botao_chip(label: str, key: str) -> bool:
    return st.button(label, key=key)

def _buscar_ids_curtidos(user_id: str, title_ids: list[str] | None = None) -> set[str]:
    if not user_id:
        return set()
    payload = {"user_id": str(user_id)}
    if title_ids:
        payload["title_ids"] = ",".join(title_ids)
    res = chamar_api("GET", "/grafo/curtidos", payload, user_id=user_id)
    if not res or not res.get("ok", False):
        return set()
    vals = res.get("title_ids", [])
    flat: list[str] = []
    for v in vals:
        if isinstance(v, (list, tuple)):
            if v:
                flat.append(str(v[0]).strip())
        else:
            flat.append(str(v).strip())
    return set(flat)

def _curtir(user_id: str, title_id: str):
    r = chamar_api("POST", "/grafo/gostou", {"user_id": str(user_id), "title_id": str(title_id)}, user_id=user_id)
    if not r or not r.get("ok"):
        st.warning("Não foi possível curtir agora.")
    else:
        st.success("Marcado como 'Gostei'!")

def _descurtir(user_id: str, title_id: str):
    r = chamar_api("DELETE", "/grafo/gostou", {"user_id": str(user_id), "title_id": str(title_id)}, user_id=user_id)
    if not r or not r.get("ok"):
        st.warning("Não foi possível descurtir agora.")
    else:
        st.toast("Removido dos curtidos.", icon="🗑️")

def _ui_generos_popover():
    caps = _capacidade_plano()
    if not caps["pode_filtrar_generos"]:
        st.caption("Seu plano não permite filtrar por gêneros.")
        return
    gens = chamar_api("GET", "/catalogo/generos") or []
    gens = sorted([g for g in gens if g], key=lambda x: x.lower())
    if hasattr(st, "popover"):
        with st.popover("Gêneros"):
            st.caption("Selecione um ou mais gêneros e clique em **Filtrar**.")
            sel_tmp = set(st.session_state.tmp_generos_sel)
            for g in gens:
                marc = st.checkbox(g, value=(g in sel_tmp), key=f"gen_cb_{g}")
                if marc: sel_tmp.add(g)
                else:    sel_tmp.discard(g)
            colf1, colf2 = st.columns(2)
            with colf1:
                if st.button("Filtrar"):
                    st.session_state.filtro_generos = list(sel_tmp)
                    st.session_state.tmp_generos_sel = list(sel_tmp)
                    st.session_state.filtro_ator = None
                    _forcar_rerun()
            with colf2:
                if st.button("Limpar"):
                    st.session_state.filtro_generos = []
                    st.session_state.tmp_generos_sel = []
                    _forcar_rerun()
    else:
        with st.expander("Gêneros (clique para abrir)"):
            st.caption("Selecione um ou mais gêneros e clique em **Filtrar**.")
            sel_tmp = set(st.session_state.tmp_generos_sel)
            for g in gens:
                marc = st.checkbox(g, value=(g in sel_tmp), key=f"gen_cb_{g}")
                if marc: sel_tmp.add(g)
                else:    sel_tmp.discard(g)
            colf1, colf2 = st.columns(2)
            with colf1:
                if st.button("Filtrar"):
                    st.session_state.filtro_generos = list(sel_tmp)
                    st.session_state.tmp_generos_sel = list(sel_tmp)
                    st.session_state.filtro_ator = None
                    _forcar_rerun()
            with colf2:
                if st.button("Limpar"):
                    st.session_state.filtro_generos = []
                    st.session_state.tmp_generos_sel = []
                    _forcar_rerun()

def _faixa_filtros_resumo():
    gen = st.session_state.filtro_generos
    ator = st.session_state.filtro_ator
    curt = st.session_state.filtro_curtidos
    if not gen and not ator and not curt:
        return
    st.markdown("#### Filtros aplicados")
    if curt:
        st.write("Curtidos: **ativos**")
    if gen:
        st.write("Gêneros:", ", ".join(gen))
    if ator:
        st.write("Ator/Atriz:", ator)
    if st.button("Limpar filtros"):
        st.session_state.filtro_generos = []
        st.session_state.tmp_generos_sel = []
        st.session_state.filtro_ator = None
        st.session_state.filtro_curtidos = False
        _forcar_rerun()

def tela_catalogo():
    caps = _capacidade_plano()
    col_titulo, col_admin, col_gen, col_curt = st.columns([3, 1, 1, 1])
    with col_titulo:
        st.subheader("Catálogo")
    with col_admin:
        u = st.session_state.usuario
        if u and u.get("is_admin"):
            if st.button("Admin"):
                ir_para("admin"); return
    with col_gen:
        _ui_generos_popover()
    with col_curt:
        rot = "Curtidos"
        if st.session_state.filtro_curtidos:
            rot += " ✅"
        if not caps["pode_curtir"]:
            st.caption("Seu plano não permite filtragem por curtidos.")
        else:
            if st.button(rot):
                st.session_state.filtro_curtidos = not st.session_state.filtro_curtidos
                _forcar_rerun()

    q = None
    if caps["pode_buscar_texto"]:
        q = st.text_input("Pesquisar por título (opcional)")
    else:
        st.caption("Seu plano não permite busca por texto.")

    _faixa_filtros_resumo()

    payload = {"user_id": (st.session_state.usuario or {}).get("id")}
    if q: payload["q"] = q
    if st.session_state.filtro_generos and caps["pode_filtrar_generos"]:
        payload["generos"] = ",".join(st.session_state.filtro_generos)
    if st.session_state.filtro_ator and caps["pode_filtrar_ator"]:
        payload["ator"] = st.session_state.filtro_ator
    if st.session_state.filtro_curtidos and st.session_state.usuario and caps["pode_curtir"]:
        payload["curtidos"] = "1"

    res = chamar_api("GET", "/catalogo", payload, user_id=(st.session_state.usuario or {}).get("id"))
    if not res:
        return

    itens = res.get("itens", [])
    if not itens:
        msg = "Nenhum título encontrado."
        if st.session_state.filtro_curtidos and caps["pode_curtir"]:
            msg = "Você ainda não tem títulos curtidos que correspondam aos filtros."
        st.info(msg); return

    curtidos_ids = set()
    if st.session_state.usuario and caps["pode_curtir"] and not st.session_state.filtro_curtidos:
        ids = [it["id"] for it in itens]
        if ids:
            curtidos_ids = _buscar_ids_curtidos(st.session_state.usuario["id"], ids)

    for item in itens:
        liked = False
        if caps["pode_curtir"]:
            liked = True if st.session_state.filtro_curtidos else (item["id"] in curtidos_ids)
        with st.container(border=True):
            st.markdown(
                f"**{item.get('titulo','(sem título)')}**  \n"
                f"*{item.get('tipo','?')}*  \n"
                f"Gêneros: {', '.join(item.get('generos', [])) or '-'}"
            )
            c1, c2 = st.columns(2)
            with c1:
                if st.button("Detalhes", key=f"det_{item['id']}"):
                    ir_para("detalhe", item["id"])
            with c2:
                if st.session_state.usuario:
                    uid = st.session_state.usuario["id"]
                    if caps["pode_curtir"]:
                        if liked:
                            if st.button("Descurtir ❤️", key=f"descurt_{item['id']}", type="primary"):
                                _descurtir(uid, item["id"]); _forcar_rerun()
                        else:
                            if st.button("Gostei ❤️", key=f"g_{item['id']}"):
                                _curtir(uid, item["id"]); _forcar_rerun()
                    else:
                        st.caption("Curtidas indisponíveis no seu plano.")

def tela_detalhe():
    caps = _capacidade_plano()
    id_titulo = st.session_state.tela_param
    st.subheader("Detalhe do Título")
    if not id_titulo:
        st.warning("ID ausente.")
        ir_para("catalogo"); return

    res = chamar_api(
        "GET",
        f"/catalogo/{id_titulo}",
        {"user_id": (st.session_state.usuario or {}).get("id")},
        user_id=(st.session_state.usuario or {}).get("id")
    )
    if not res:
        return
    t = res["titulo"]
    st.markdown(f"### {t['titulo']} ({t.get('tipo')})")
    st.write("**Sinopse:**", t.get("sinopse") or "-")
    st.write("**Classificação:**", t.get("classificacao") or "-")

    generos = t.get("generos", [])
    if generos:
        st.write("**Gêneros:**")
        cols = st.columns(max(1, min(len(generos), 4)))
        for i, g in enumerate(generos):
            with cols[i % len(cols)]:
                if st.button(g, key=f"chip_gen_{g}_{t['id']}"):
                    if _capacidade_plano()["pode_filtrar_generos"]:
                        st.session_state.filtro_generos = [g]
                        st.session_state.tmp_generos_sel = [g]
                        st.session_state.filtro_ator = None
                        st.session_state.filtro_curtidos = False
                        ir_para("catalogo")
                    else:
                        # plano comum: não faz nada
                        pass

    elenco = t.get("elenco", [])
    if elenco:
        st.write("**Elenco:**")
        cols = st.columns(max(1, min(len(elenco), 4)))
        for i, a in enumerate(elenco):
            with cols[i % len(cols)]:
                if st.button(a, key=f"chip_atr_{a}_{t['id']}"):
                    # Somente DELUX pode filtrar por elenco; comum/premium: não faz nada
                    if _capacidade_plano()["pode_filtrar_ator"]:
                        st.session_state.filtro_ator = a
                        st.session_state.filtro_generos = []
                        st.session_state.tmp_generos_sel = []
                        st.session_state.filtro_curtidos = False
                        ir_para("catalogo")
                    else:
                        # plano comum/premium: não faz nada
                        pass

    if t.get("tipo") == "filme":
        st.write("**Duração (min):**", t.get("duracao_min") or "-")
    else:
        temporadas = t.get("temporadas")
        eps_por_temp = t.get("eps_por_temp") or []
        st.write("**Temporadas:**", temporadas or "-")
        if temporadas:
            for i, qtd in enumerate(eps_por_temp, start=1):
                st.write(f"- Temporada {i}: {qtd} episódio(s)")

    c1, c2 = st.columns(2)
    with c1:
        if st.button("Voltar ao catálogo"):
            ir_para("catalogo")
    with c2:
        if st.session_state.usuario:
            uid = st.session_state.usuario["id"]
            if caps["pode_curtir"]:
                liked_ids = _buscar_ids_curtidos(uid, [id_titulo])
                liked = id_titulo in liked_ids
                if liked:
                    if st.button("Descurtir ❤️", key=f"det_descurt_{id_titulo}", type="primary"):
                        _descurtir(uid, id_titulo); _forcar_rerun()
                else:
                    if st.button("Gostei ❤️", key=f"det_like_{id_titulo}"):
                        _curtir(uid, id_titulo); _forcar_rerun()
            else:
                st.caption("Curtidas indisponíveis no seu plano.")

def tela_admin():
    u = st.session_state.usuario
    if not (u and u.get("is_admin")):
        st.warning("Acesso restrito a administradores.")
        if st.button("Voltar ao catálogo"):
            ir_para("catalogo")
        return

    st.subheader("Admin — Cadastrar/Excluir Títulos")

    # Cadastrar
    with st.expander("Cadastrar novo título", expanded=True):
        tipo = st.selectbox("Tipo", ["filme", "serie"], key="tipo_admin")
        titulo = st.text_input("Título")
        sinopse = st.text_area("Sinopse")
        classificacao = st.text_input("Classificação (ex.: 12, 16...)")
        generos = st.text_input("Gêneros (separados por vírgula)")
        elenco = st.text_input("Elenco (separado por vírgula)")
        ano = st.number_input("Ano", min_value=1900, max_value=2100, step=1, value=2020)

        # VISIBILIDADE POR PLANO
        vis_opt = st.selectbox(
            "Disponível para qual(is) plano(s)?",
            ["comum", "premium", "comum e premium"], index=2
        )
        vis_comum = (vis_opt in ["comum", "comum e premium"])
        vis_premium = (vis_opt in ["premium", "comum e premium"])

        duracao_min = None
        temporadas = None
        eps_por_temp = None

        if tipo == "filme":
            duracao_min = st.number_input("Duração (min)", min_value=1, step=1)
        else:
            temporadas = st.number_input("Quantidade de temporadas", min_value=1, step=1, value=1)
            eps_por_temp = []
            for i in range(int(temporadas)):
                qtd = st.number_input(
                    f"Episódios na temporada {i+1}",
                    min_value=1, step=1,
                    key=f"eps_t{i+1}"
                )
                eps_por_temp.append(int(qtd))

        if st.button("Cadastrar"):
            payload = {
                "titulo": titulo,
                "tipo": tipo,
                "sinopse": sinopse or None,
                "classificacao": classificacao or None,
                "generos": [g.strip() for g in generos.split(",") if g.strip()],
                "elenco": [a.strip() for a in elenco.split(",") if a.strip()],
                "ano": int(ano),
                "disponivel": True,
                "vis_comum": vis_comum,
                "vis_premium": vis_premium,
            }
            if tipo == "filme":
                payload["duracao_min"] = int(duracao_min) if duracao_min else None
            else:
                payload["temporadas"] = int(temporadas)
                payload["eps_por_temp"] = eps_por_temp

            res = chamar_api("POST", "/admin/titulos", payload, user_id=u["id"])
            if res and res.get("id"):
                st.success(f"Cadastrado com id {res['id']}")

    # Excluir — confirmação INLINE (sem modal)
    with st.expander("Excluir título", expanded=True):
        # >>> RESET SEGURO ANTES DE CRIAR O SELECTBOX
        if st.session_state.get("admin_reset_select"):
            for k in ("admin_sel_nome", "admin_sel_id", "admin_sel_titulo"):
                st.session_state.pop(k, None)
            st.session_state.admin_reset_select = False

        lista = chamar_api("GET", "/admin/titulos/lista", user_id=u["id"]) or []
        if not lista:
            st.info("Não há títulos cadastrados.")
        else:
            opcoes = {f"{it['titulo']} ({it['tipo']})": it["id"] for it in lista}
            nomes = ["— selecione —"] + list(opcoes.keys())

            # Ajuste do valor antes de instanciar o widget (seguro)
            if st.session_state.get("admin_sel_nome") not in nomes:
                st.session_state.admin_sel_nome = "— selecione —"

            def _on_sel_change():
                nome = st.session_state.admin_sel_nome
                if nome and nome != "— selecione —":
                    st.session_state.admin_sel_titulo = nome
                    st.session_state.admin_sel_id = opcoes[nome]
                else:
                    st.session_state.admin_sel_titulo = None
                    st.session_state.admin_sel_id = None

            st.selectbox(
                "Escolha o título para excluir",
                nomes,
                key="admin_sel_nome",
                on_change=_on_sel_change
            )

            # Bloco de confirmação inline (sempre aparece ao selecionar)
            if st.session_state.admin_sel_id:
                with st.container(border=True):
                    st.warning(f"Deseja realmente excluir **\"{st.session_state.admin_sel_titulo}\"**?")
                    colm1, colm2 = st.columns(2)
                    with colm1:
                        if st.button("Sim, excluir", key="btn_conf_excluir"):
                            chamar_api("DELETE", f"/admin/titulos/{st.session_state.admin_sel_id}", user_id=u["id"])
                            # Em vez de escrever no widget agora, sinaliza reset para o PRÓXIMO ciclo
                            st.session_state.admin_sel_id = None
                            st.session_state.admin_sel_titulo = None
                            st.session_state.admin_reset_select = True
                            st.toast("Título excluído (verifique o catálogo).", icon="🗑️")
                            _forcar_rerun()
                    with colm2:
                        if st.button("Não, cancelar", key="btn_canc_excluir"):
                            # Apenas sinaliza reset; não escreve na key do widget nesta renderização
                            st.session_state.admin_sel_id = None
                            st.session_state.admin_sel_titulo = None
                            st.session_state.admin_reset_select = True
                            _forcar_rerun()

    if st.button("Voltar ao catálogo"):
        ir_para("catalogo")

# -----------------------------
# Main
# -----------------------------
def main():
    cabecalho()
    tela = st.session_state.tela
    if tela == "login":
        tela_login()
    elif tela == "cadastro":
        tela_cadastro()
    elif tela == "planos":
        tela_planos()
    elif tela == "pagamento":
        tela_pagamento()
    elif tela == "catalogo":
        # se estiver logado e sem plano, mandar escolher
        if st.session_state.usuario and not st.session_state.tem_assinatura:
            ir_para("planos"); return
        tela_catalogo()
    elif tela == "detalhe":
        tela_detalhe()
    elif tela == "admin":
        tela_admin()
    else:
        ir_para("login")

if __name__ == "__main__":
    main()
