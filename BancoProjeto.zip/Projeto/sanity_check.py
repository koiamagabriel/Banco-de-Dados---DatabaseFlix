# Projeto/sanity_check.py

# Supabase via REST (API URL)
from db.supabase_rest import sb_ping, sb_insert_usuario, sb_select_ultimo_usuario

# MongoDB (confira seu arquivo db/mongo.py)
from db.mongo import mongo_ping, mongo_ensure_minimal_schema, mongo_db

# Neo4j (confira seu arquivo db/neo4j_db.py)
from db.neo4j_db import neo4j_ping, neo4j_ensure_minimal_schema, neo4j_driver

def test_supabase_rest():
    print("→ Supabase REST: ping...", "OK" if sb_ping() else "FAIL")
    sb_insert_usuario("Usuário Demo", "demo@example.com")
    u = sb_select_ultimo_usuario()
    print("  Último usuário (REST):", u[0] if u else None)

def test_mongo():
    print("→ MongoDB: ping...", "OK" if mongo_ping() else "FAIL")
    mongo_ensure_minimal_schema()
    doc = mongo_db().titulos.find_one({}, {"_id": 0, "titulo": 1, "generos": 1})
    print("  Título exemplo:", doc)

def test_neo4j():
    print("→ Neo4j: ping...", "OK" if neo4j_ping() else "FAIL")
    neo4j_ensure_minimal_schema()
    with neo4j_driver().session() as s:
        res = s.run("""
            MATCH (u:User)-[:ASSISTIU]->(t:Title)-[:PERTENCE_A]->(g:Genre)
            RETURN u.nome AS usuario, t.titulo AS titulo, g.nome AS genero
            LIMIT 1
        """).single()
        print("  Relação exemplo:", dict(res) if res else None)
 
 
if __name__ == "__main__":
    test_supabase_rest()
    test_mongo()
    test_neo4j()
    print("\nSanity check concluído.")
